/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.restaurant_management_system;

/**
 *
 * @author rehma
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OrderAppGUI {
    private OrderService orderService = new OrderService();

    
    private Map<String, Double> menuItems = new HashMap<>();

    public OrderAppGUI() {
        
        menuItems.put("Burger", 5.99);
        menuItems.put("Pizza Slice", 3.49);
        menuItems.put("French Fries", 2.99);
        menuItems.put("Hot Dog", 4.49);
        menuItems.put("Soda", 1.99);
        menuItems.put("Chicken Nuggets", 6.99);
    }

    public void createAndShowGUI() {
        JFrame frame = new JFrame("Restaurant Management System - Order");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 500);
        frame.setLayout(new BorderLayout());

        // Input Panel
        JPanel inputPanel = new JPanel(new GridLayout(4, 2));

       
        JComboBox<String> itemDropdown = new JComboBox<>(menuItems.keySet().toArray(new String[0]));
        JTextField quantityField = new JTextField();
        JTextField priceField = new JTextField();
        priceField.setEditable(false); 

        inputPanel.add(new JLabel("Item:"));
        inputPanel.add(itemDropdown);
        inputPanel.add(new JLabel("Quantity:"));
        inputPanel.add(quantityField);
        inputPanel.add(new JLabel("Price per Item:"));
        inputPanel.add(priceField);

        JButton placeOrderButton = new JButton("Place Order");
        inputPanel.add(placeOrderButton);

        frame.add(inputPanel, BorderLayout.NORTH);

        
        JTextArea orderListArea = new JTextArea();
        orderListArea.setEditable(false);
        frame.add(new JScrollPane(orderListArea), BorderLayout.CENTER);

        // Update price based on selected item
        itemDropdown.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedItem = (String) itemDropdown.getSelectedItem();
                if (selectedItem != null) {
                    priceField.setText(String.valueOf(menuItems.get(selectedItem)));
                }
            }
        });

        // Event handling for "Place Order" button
        placeOrderButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String itemName = (String) itemDropdown.getSelectedItem();
                    int quantity = Integer.parseInt(quantityField.getText());
                    double price = menuItems.get(itemName);

                    orderService.placeOrder(itemName, quantity, price);

                    // Clear input fields
                    quantityField.setText("");

                    // Update order list display
                    displayAllOrders(orderListArea);

                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Please enter a valid quantity.");
                }
            }
        });

        // Display all orders initially
        displayAllOrders(orderListArea);

        frame.setVisible(true);
    }

    private void displayAllOrders(JTextArea orderListArea) {
        List<Order> orders = orderService.getAllOrders();
        StringBuilder sb = new StringBuilder();
        for (Order order : orders) {
            sb.append(order.toString()).append("\n");
        }
        orderListArea.setText(sb.toString());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new OrderAppGUI().createAndShowGUI();
        });
    }
}
